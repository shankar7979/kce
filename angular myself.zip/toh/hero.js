"use strict";
class Hero {
}
exports.Hero = Hero;
//# sourceMappingURL=hero.js.map