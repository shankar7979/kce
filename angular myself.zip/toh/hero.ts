export class Hero{  /*创建英雄类 */
  id:number;
  name:string;
}