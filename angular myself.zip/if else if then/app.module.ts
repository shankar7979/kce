import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { NgIfComponent } from './ngif.component';
import { NgIfElseComponent} from './ngif-else.component';
import { FormsModule } from '@angular/forms';
import { NgIfThenElseComponent } from './ngif-then-else.component';



@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    NgIfComponent,
    NgIfElseComponent,
    NgIfThenElseComponent 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
