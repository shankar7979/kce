import { Component, ViewChild, TemplateRef, OnInit } from '@angular/core';

@Component({
   selector: 'app-ngif-then-else',
   templateUrl: './ngif-then-else.component.html'
})
export class NgIfThenElseComponent implements OnInit { 
	 isValid: boolean = true;	
	 age:number = 12;		 
	 myThenBlock: TemplateRef<any> = null;
	 myElseBlock: TemplateRef<any> = null;	
	 
	 @ViewChild('firstThenBlock')
	 firstThenBlock: TemplateRef<any> = null;
	 @ViewChild('secondThenBlock')
	 secondThenBlock: TemplateRef<any> = null;	
	 
	 @ViewChild('firstElseBlock')
     firstElseBlock: TemplateRef<any> = null;
     @ViewChild('secondElseBlock')
     secondElseBlock: TemplateRef<any> = null;
	 
	 ngOnInit() {
	   this.myThenBlock = this.firstThenBlock;
	   this.myElseBlock = this.firstElseBlock;
	 }
	 changeValue(valid: boolean) {
	   this.isValid = valid;
	 }
	 toggleThenBlock() {
	   this.myThenBlock = this.myThenBlock === this.firstThenBlock ? this.secondThenBlock : this.firstThenBlock; 
	 }
	 toggleElseBlock() {
	   this.myElseBlock = this.myElseBlock === this.firstElseBlock ? this.secondElseBlock : this.firstElseBlock;
	 }
}
    