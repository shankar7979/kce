import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  Validators
} from '@angular/forms';

@Component({
  selector: 'app-login-form1',
  templateUrl: './login-form1.component.html',
  styleUrls: ['./login-form1.component.css']
})
export class LoginForm1Component implements OnInit {

  loginForm: FormGroup;
  username: FormControl;
  password: FormControl;

  constructor (builder: FormBuilder) {
    this.username = new FormControl('', [
      Validators.required,
      Validators.minLength(5)
    ]);
    this.password = new FormControl('', [Validators.required]);
    this.loginForm = builder.group({
      username: this.username,
      password: this.password
    });
  }
  login () {
    console.log(this.loginForm.value);
    // Attempt Logging in...
  }

  ngOnInit() {
  }

}
