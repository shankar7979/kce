import { Component, OnInit } from '@angular/core';
import {
  REACTIVE_FORM_DIRECTIVES,
  FormBuilder,
  FormControl,
  Validators
} from '@angular/forms';


function hasExclamationMark (input: FormControl) {
  const hasExclamation = input.value.indexOf('!') >= 0;

  return hasExclamation ? null : { needsExclamation: true };
}

@Component({
  selector: 'app-login-forms',
  templateUrl: './login-forms.component.html',
  styleUrls: ['./login-forms.component.css'],
  directives: [REACTIVE_FORM_DIRECTIVES]

})
export class LoginFormsComponent implements OnInit {
  loginForm: FormGroup;
  username: FormControl;
  password: FormControl;

  constructor (builder: FormBuilder) {
    this.username = new FormControl('', [
      Validators.required,
      Validators.minLength(5)
    ]);
    this.password = new FormControl('', [Validators.required, hasExclamationMark]);
    this.loginForm = builder.group({
      username: this.username,
      password: this.password
    });
  }
  login () {
    console.log(this.loginForm.value);
    // Attempt Logging in...
  }
  ngOnInit() {
  }

}
