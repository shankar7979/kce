import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WorkoutRunnerModule } from './workout-runner/workout-runner.module';
import { NameEditorComponent } from './name-editor/name-editor.component';
import { ReactiveFormsModule } from '@angular/forms';
import { TemplateFormsComponent } from './template-forms/template-forms.component';
import { FormsModule } from '@angular/forms';
import { LoginFormsComponent } from './login-forms/login-forms.component';
import { LoginForm1Component } from './login-form1/login-form1.component';


@NgModule({
  declarations: [
    AppComponent,
    NameEditorComponent,
    TemplateFormsComponent,
    LoginFormsComponent,
    LoginForm1Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    WorkoutRunnerModule,
    ReactiveFormsModule,
    FormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
