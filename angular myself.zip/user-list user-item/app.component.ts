import { Component , Input} from '@angular/core';
import { ProductService } from './product/product.service';
	@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[ProductService]
})
export class AppComponent {
   title:string;
   
   imageUrl="assets/img1.jpg";
   imageWidth:number=50;
   imageHeight:number=40;
   
    @Input() country:string;                             
  constructor(){
	  this.title='angular js';
  }
  
  onClick($event){
       alert('clicked')
	  console.log("clicked",$event)
  } 
}
							   
