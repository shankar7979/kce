import { Component,OnInit } from '@angular/core';

@Component({
  selector: 'rating',
  templateUrl: './rating.component.html',
  styleUrls: ['./rating.component.css']
})

export class RatingComponent{
    rating = 0;

    onClick(ratingValue){
        this.rating = ratingValue;
    }
} 
