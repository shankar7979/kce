import { Component,OnInit } from '@angular/core';
import { ProductService } from './product.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})

export class ProductComponent implements OnInit {

  prdId:number;
  prdname:string;
  prd_date:Date;
  prod_cost:number;
  //products:string[];
  products;
  
/*  
  constructor() { 
	  this.prdId=1001;
	  this.prdname="angular2 in action";
	  this.products=["book","pen","mobile","pant","shirt"];
	  }
 */

  constructor(productService:ProductService) { 
	  this.prdId=1001;
	  this.prdname="angular2 in action";   
	  this.prd_date=new Date('10-10-2019 12:44:33');   
	  this.products=productService.getProducts()
	  this.prod_cost=556566.678;
	  }
 
  ngOnInit() {
  }

}
