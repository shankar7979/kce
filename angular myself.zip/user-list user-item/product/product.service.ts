export class ProductService{
	
	getProducts():string[]{
		
		return ["mobile","book", "pen","jeans"];
	}
	
}
