import java.time.LocalTime;
import java.util.Timer;
import java.util.TimerTask;

public class Main {


    public static void main(String[] args) {

        Timer time = new Timer();
        TimerTask task= new TimerTask() {
            int i=0;
            @Override
            public void run() {
                MM1Queue mm =new MM1Queue();

                if(mm.q1.isEmpty()){
                    Packet p= new Packet();
                    p.id=i++;
                    mm.q1.add(p);
                    System.out.println("Schedule Packet Arrival");

                }
                else if(mm.q1.size()==5 ){
                    System.out.println("Drop the packet");
                    System.out.println("Schedule Departure"+mm.q1.remove());
                }

                else if(!mm.q1.isEmpty()){

                    System.out.println("Schedule Departure"+mm.q1.remove());

                }

                else{
                    Packet p= new Packet();
                    p.id=i++;
                    mm.q1.add(p);
                    System.out.println("Packet Enqued");
                }


            }
        };


        float ARR=Float.parseFloat(args[0]);

        float ENDTIME=Float.parseFloat(args[1]);

        time.schedule(task, (long) ARR);
        LocalTime lt= LocalTime.now();
        LocalTime lt1=lt.plusSeconds((long) ENDTIME);


        if(lt==lt1){
            time.cancel();
        }

    }

}
