public class Packet implements Comparable<Packet> {


    int id;


    @Override
    public int compareTo(Packet o) {
        return 0;
    }
}
