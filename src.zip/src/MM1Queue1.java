import java.util.PriorityQueue;
import java.util.Queue;

public class MM1Queue1 {

  Queue<Packet> q1;


    MM1Queue1(int size){

      q1=new PriorityQueue<>(size);

    }

      public void add(Packet packet){

      q1.add(packet);


      }


      public int size(){

      return q1.size();

      }

      public Packet get(){

      return q1.peek();
      }

    public Packet remove(int i){

      return q1.remove();

    }



}
