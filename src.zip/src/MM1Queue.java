
import java.util.*;

public class MM1Queue {

  Queue<Packet> q1;


    MM1Queue(){

      q1=new PriorityQueue<>();

    }

      public void add(Packet packet){

      q1.add(packet);

      }


      public int size(){
      return q1.size();

      }


      public Packet get(){
      return q1.peek();
      }

    public Packet remove(int i){



      return q1.remove();

    }



}
