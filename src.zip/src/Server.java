public class Server {

    Double currentime;
    Double servetime;

    Server(){
        currentime=0.0;

        servetime=0.0;
    }

    public void packetarrival()

    {

        System.out.println("Packet Arrival"+currentime +" Serve time" + servetime);
    }

    public void packetdeparture()

    {

        System.out.println("Packet Departure"+currentime +" Serve time" + servetime);
    }

}
