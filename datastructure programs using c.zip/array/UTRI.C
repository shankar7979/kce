/*Program to check upper triangular matrix*/

#include<stdio.h>
#include<conio.h>
void main()
{
int a[5][5],i,j,n;
char ch='y';
clrscr();
 printf("Enter the order of matrix: ");
 scanf("%d",&n);
 printf("Elements of matrix are: \n");
 for(i=0;i<n;++i)
  for(j=0;j<n;++j)
    scanf("%d",&a[i][j]);
  for(i=0;i<n;++i)
   for(j=0;j<n;++j)
    if((i>j)&&(a[i][j]!=0))
      ch='n';
 if(ch=='y')
 printf("Given matrix is UPPER TRIANGULAR MATRIX");
 else
 printf("Given matrix is NOT UPPER TRIANGULAR MATRIX");

getch();
}