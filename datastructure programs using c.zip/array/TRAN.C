/*Program to find transpose of a matrix*/

#include<stdio.h>
#include<conio.h>
void main()
{
int a[5][5],b[5][5],i,j,m,n;
clrscr();
 printf("Enter row of matrix: ");
 scanf("%d",&m);
 printf("Enter column of matrix: ");
 scanf("%d",&n);

 printf("Elements of matrix are: \n");
   for(i=0;i<m;++i)
    for(j=0;j<n;++j)
       scanf("%d",&a[i][j]);

   for(i=0;i<m;++i)
    for(j=0;j<n;++j)
     b[j][i]=a[i][j];
     printf("Elements of resultant matrix are: \n");
	       for(i=0;i<n;++i)
		{ for(j=0;j<m;++j)
		    printf("%5d",b[i][j]);
		  printf("\n");
		}
  getch();
 }