/*Program for deletion of an element from an array*/

#include<stdio.h>
#include<conio.h>
main()
{
  int a[20],n,i,item,loc;
  clrscr();
  printf("Enter size of the array : ");
  scanf("%d",&n);
  printf("\nEnter elements in the array : \n");
   for(i=0;i<n;++i)
    scanf("%d",&a[i]);
  printf("\nEnter the location from where you want to delete element : ");
  scanf("%d",&loc);
     item=a[loc-1];
   for(i=loc-1;i<n;i++)
   {
     a[i]=a[i+1];
   }
     n--;
     printf("\nDeleted no is : %d from location %d",item,loc);
     printf("\n\nNew array is : \n");
      for(i=0;i<n;++i)
       printf("\n%d",a[i]);

  getch();
}
