/*Program for check symmetric matrix*/

#include<stdio.h>
#include<conio.h>
void main()
{
int a[5][5],i,j,n;
char ch='y';
clrscr();
 printf("Enter the order of matrix: ");
 scanf("%d",&n);
 printf("Elements of matrix are: \n");
   for(i=0;i<n;++i)
    for(j=0;j<n;++j)
       scanf("%d",&a[i][j]);

   for(i=0;i<n;++i)
    for(j=0;j<n;++j)
     if(a[i][j]!=a[j][i])
	   ch='n';
	   if(ch=='y')
	   printf("Given matrix is SYMMETRIC MATRIX");
	   else
	      printf("Given matrix is NOT SYMMETRIC MATRIX");
 getch();
}
