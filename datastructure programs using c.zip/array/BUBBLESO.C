/*Program for sorting elements in an array*/

#include<stdio.h>
#include<conio.h>
main()
{
  int a[20],n,i,j,temp;
  clrscr();
  printf("Enter size of the array : ");
  scanf("%d",&n);
  printf("\nEnter elements in the array : \n");
   for(i=0;i<n;++i)
    scanf("%d",&a[i]);

   for(i=0;i<n-1;++i)
   {
     for(j=0;j<n-i-1;j++)
     {
       if(a[j]>a[j+1])
       { temp=a[j];
	 a[j]=a[j+1];
	 a[j+1]=temp;
       }
     }
   }
   printf("\nSorted array is :\n ");
   for(i=0;i<n;i++)
     printf("\n%d",a[i]);
 getch();
}
