/*Program to find sum of two matrices*/

#include<stdio.h>
#include<conio.h>
main()
{ int a[5][5],b[5][5],sum[5][5];
  int r,c,i,j;
  clrscr();
  printf("Enter order of matrices:\n ");
  printf("\nRow of matrices : ");
  scanf("%d",&r);
  printf("Column of matrices : ");
  scanf("%d",&c);
  printf("\nEnter elements of first matrix : \n");
   for(i=0;i<r;i++)
    { for(j=0;j<c;j++)
	scanf("%d",&a[i][j]);
    }

  printf("\nEnter elements of second matrix : \n");
   for(i=0;i<r;i++)
    { for(j=0;j<c;j++)
	scanf("%d",&b[i][j]);
    }

   for(i=0;i<r;i++)
    { for(j=0;j<c;j++)
	sum[i][j]=a[i][j]+b[i][j];
    }

    printf("\nResultant matrix is: \n");
    for(i=0;i<r;i++)
    { for(j=0;j<c;j++)
	printf("%5d",sum[i][j]);
	printf("\n");
    }
   getch();
}
