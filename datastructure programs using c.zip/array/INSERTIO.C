/*Program for insertion an element in an array*/

#include<stdio.h>
#include<conio.h>
main()
{
  int a[20],n,i,item,loc;
  clrscr();
  printf("Enter size of the array : ");
  scanf("%d",&n);
  printf("\nEnter elements in the array : \n");
   for(i=0;i<n;++i)
    scanf("%d",&a[i]);
  printf("\nEnter the location where you want to insert : ");
  scanf("%d",&loc);
  printf("\nEnter element to be inserted : ");
  scanf("%d",&item);

   for(i=n-1;i>=loc-1;i--)
   {
     a[i+1]=a[i];
   }
     a[loc-1]=item;
     n++;
     printf("\nNew array is : \n");
      for(i=0;i<n;++i)
       printf("\n%d",a[i]);
  getch();
}
