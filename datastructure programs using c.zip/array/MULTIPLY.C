/*Program for multiplication of two matrices*/

#include<stdio.h>
#include<conio.h>
main()
{ int a[5][5],b[5][5],c[5][5];
  int r1,c1,r2,c2,i,j,k;
  clrscr();
  printf("Enter order of 1st matrix:\n ");
  printf("\nRow of 1st matrix : ");
  scanf("%d",&r1);
  printf("Column of 1st matrix : ");
  scanf("%d",&c1);

  printf("\nEnter order of 2nd matrix:\n ");
  printf("\nRow of 2nd matrix : ");
  scanf("%d",&r2);
  printf("Column of 2nd matrix : ");
  scanf("%d",&c2);
  if(c1!=r2)
  { printf("\nMultiplication is not possible");
    printf("\nOrder of matrices are not suitable for multiplication");
    getch();
    exit();
  }

  printf("\nEnter elements of first matrix : \n");
   for(i=0;i<r1;i++)
    { for(j=0;j<c1;j++)
	scanf("%d",&a[i][j]);
    }

  printf("\nEnter elements of second matrix : \n");
   for(i=0;i<r2;i++)
    { for(j=0;j<c2;j++)
	scanf("%d",&b[i][j]);
    }

   for(i=0;i<r1;i++)
    { for(j=0;j<c2;j++)
       { c[i][j]=0;
	 for(k=0;k<c1;k++)
	  { c[i][j]=c[i][j]+a[i][k]*b[k][j];
	  }
       }
    }

    printf("\nResultant matrix is: \n");
    for(i=0;i<r1;i++)
    { for(j=0;j<c2;j++)
	printf("%5d",c[i][j]);
	printf("\n");
    }
   getch();
}
