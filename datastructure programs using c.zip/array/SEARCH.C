/*Program for searching an element in an array*/

#include<stdio.h>
#include<conio.h>
main()
{
  int a[20],ele,n,i;
  clrscr();
  printf("Enter size of the array : ");
  scanf("%d",&n);
  printf("\nEnter elements in the array : \n");
   for(i=0;i<n;++i)
    scanf("%d",&a[i]);
  printf("\nEnter element to be searched : ");
  scanf("%d",&ele);
   for(i=0;i<n;++i)
   { if(a[i]==ele)
     { printf("\nElement found at %d location ",i+1);
       getch();
       exit();
     }
  }
     printf("\nElement is not in the array");
     getch();
}
