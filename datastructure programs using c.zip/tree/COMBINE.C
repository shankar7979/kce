/*Program to create and ALL 3 traversal of a Binary Tree*/

#include<stdio.h>
#include<conio.h>
#include<alloc.h>
#include<graphics.h>
struct tree
 {
   char info;
   struct tree *left;
   struct tree *right;
 };
 struct tree *root,*head,*temp;

void main()
{
  char choice;
  int gd=DETECT,gm;
  initgraph(&gd,&gm," ");

  printf("Please create a binary tree : \n");
  root=NULL;
    create();

    cleardevice();
    gotoxy(5,1);
    printf("\n\nTree Entered is : \n");
     display(root);
     gotoxy(20,20);
    printf("\nTree Traversal : ");
    printf("\n\nPre-Order Traversal : \n");
    pre(root);
    printf("\n\nIn-Order Traversal : \n");
    in(root);
    printf("\n\nPost-Order Traversal : \n");
    post(root);
    getch();
    closegraph();
}

//FUNCTION TO CREATE NODES OF A BINARY TREE
create()
{   char item,ch;
    struct tree *queue[20];
    int front=0,rear=0;

    head=(struct tree*)malloc(sizeof(struct tree));
    printf("\n\nEnter information to be stored : " );
    scanf("%c",&item);
    head->info=item;
    root=head;

    rear++;
    queue[rear]=head;

    while(front!=rear)
    {
       front++;
       temp=queue[front];

    //Left Child
    printf("\n\nIs %c has Left child (Y/N)...",temp->info);
    fflush(stdin);
    scanf("%c",&ch);

    if(ch=='y'||ch=='Y')
    {
     head=(struct tree*)malloc(sizeof(struct tree));
     printf("\n\nEnter information of Left Child : " );
     fflush(stdin);
     scanf("%c",&item);
     head->info=item;
     temp->left=head;
     rear++;
     queue[rear]=head;
    }
    else
      temp->left=NULL;

    //Right Child
    printf("\n\nIs %c has Right child (Y/N)...",temp->info);
    fflush(stdin);
    scanf("%c",&ch);

    if(ch=='y'||ch=='Y')
    {
     head=(struct tree*)malloc(sizeof(struct tree));
     printf("\n\nEnter information of Right Child : " );
       fflush(stdin);
     scanf("%c",&item);
     head->info=item;
     temp->right=head;
     rear++;
     queue[rear]=head;
    }
    else
      temp->right=NULL;
  }

  return;
}


//TO DISPLAY THE TREE
display(struct tree *ptr)
{
   int top;
   struct tree *stack[20];
   int x=300,y=50,a[10],b[10],c[10],dec=200,level=0,x1=300,y1=50;
   char item[1];
   top=1;
   stack[1]=NULL;

   while(ptr!=NULL)
   {
     //itoa(x,item,10);
     item[0]=ptr->info;
     item[1]='\0';
     setcolor(RED);
     outtextxy(x,y,item);

     if(x!=x1)
      { setcolor(YELLOW);
	line(x1,y1+10,x,y-5);
      }
     x1=x;y1=y;

    //Right Child
    if(ptr->right!=NULL)
    {
      top=top+1;
      stack[top]=ptr->right;
      a[top]=level+1;
      b[top]=(x+dec/2);
      c[top]=dec/2;
    }

    //Left Child
    if(ptr->left!=NULL)
      {
	level++;
	dec=dec/2;
	x=x-dec;
	ptr=ptr->left;
      }
    else
    {
      level=a[top];
      dec=c[top];
      x=b[top];
      ptr=stack[top];
      top=top-1;
       x1=x-dec;
       y1=(50*(level-1))+50;
    }
      y=50+50*level;
  }
 return;
}


//In Order Traversal
in(struct tree *ptr)
{
  if(ptr!=NULL)
  {
   in(ptr->left);
   printf("%c  ",ptr->info);
   in(ptr->right);
  }
  return;
}

//Pre Order Traversal
pre(struct tree *ptr)
{
  if(ptr!=NULL)
  {
   printf("%c  ",ptr->info);
   pre(ptr->left);
   pre(ptr->right);
  }
  return;
}

//Post Order Traversal
post(struct tree *ptr)
{
  if(ptr!=NULL)
  {
   post(ptr->left);
   post(ptr->right);
   printf("%c  ",ptr->info);
  }
  return;
}

