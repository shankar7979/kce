/*Tree Traversal and Display of Tree { Created by: Manoj (1003/05) }*/

#include<conio.h>
#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>
struct node
{ struct node *l;
  int num;
  struct node *r;
}*root=NULL,*q;
char str[5];
void main()
{  int x1=320,y1=60,x=120;
   int gd=DETECT,gm;
   initgraph(&gd,&gm,"");
   cleardevice();
   q=(struct node*)malloc(sizeof(struct node));
   allocate();
   printf("\n enter the root node NUMBER\n");
   scanf("%d",&q->num);
   root=q;
   insert(root);
   clrscr();
   cleardevice();
   setcolor(GREEN);
   outtextxy(20,20,"tree DISPLAY ");
   outtextxy(x1,y1,itoa(root->num,str,10));
   disp(root,x1,y1+10,x);
   getch();
   gotoxy(2,20);
   printf("\nPREORDER TRAVERSE\n");
   preorder(root);
   printf("\nINORDER TRAVERSE\n");
   inorder(root);
   printf("\nPOSTORDER TRAVERSE\n");
   postorder(root);
   deallocate(root);
   getch();
}
allocate()
 {
   if(q==NULL)
   { printf(" overflow\n");
    getch();
    exit(0);
   }
   return;
}

insert(struct node *ptr)
{ char ch;
  printf("\n do u want to insert LEFT node of %d ...(Y/N)?\n",ptr->num);
  fflush(stdin);
  ch=getche();
  if(ch!='y'&&ch!='Y')
    ptr->l=NULL;
  else
   {  q=(struct node*)malloc(sizeof(struct node));
      allocate();
      printf("\n enter the number to be insert in LEFT of %d \n",ptr->num);
      scanf("%d",&q->num);
      ptr->l=q;
      insert(ptr->l);
   }
   printf("\n do u want to insert RIGHT node of %d ...(Y/N)\n",ptr->num);
   fflush(stdin);
   ch=getche();
   if(ch!='y'&&ch!='Y')
     ptr->r=NULL;
   else
   { q=(struct node*)malloc(sizeof(struct node));
     allocate();
     printf("\n enter the number to be insert in RIGHT of %d \n",ptr->num);
     scanf("%d",&q->num);
     ptr->r=q;
     insert(ptr->r);
   }
   return;
 }

disp(struct node *ptr,int x1,int y1,int x)
{  if(ptr!=NULL)
   { if(ptr->l!=NULL)
     { line(x1,y1,x1-x,y1+30);
       outtextxy(x1-x,y1+35,itoa(ptr->l->num,str,10));
       x=x/2;
       disp(ptr->l,x1-2*x,y1+45,x);
       x=2*x;
     }
     if(ptr->r!=NULL)
     { line(x1,y1,x1+x,y1+30);
       outtextxy(x1+x,y1+35,itoa(ptr->r->num,str,10));
       x=x/2;
       disp(ptr->r,x1+2*x,y1+45,x);
     }
   }
  return;
}

preorder(struct node *ptr)
{ if(ptr!=NULL)
  {printf("%5d",ptr->num);
  preorder(ptr->l);
  preorder(ptr->r);
  }
  return;
}
inorder(struct node *ptr)
{ if(ptr!=NULL)
  {
  inorder(ptr->l);
  printf("%5d",ptr->num);
  inorder(ptr->r);
  }
  return;
}
postorder(struct node *ptr)
{ if(ptr!=NULL)
  {
   postorder(ptr->l);
   postorder(ptr->r);
   printf("%5d",ptr->num);
  }
  return;
}
deallocate(struct node *ptr)
{
  if(ptr!=NULL)
  { deallocate(ptr->l);
    deallocate(ptr->r);
    free(ptr);
  }
 return;
}