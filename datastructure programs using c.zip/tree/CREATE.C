/*Program to create and display a Binary Tree*/

#include<stdio.h>
#include<conio.h>
#include<alloc.h>
struct tree
 {
   char info;
   struct tree *left;
   struct tree *right;
 };
 struct tree *root,*head,*temp;
   int in(struct tree*);
    int create(void) ;
void main()
{
  char choice;
  clrscr();
  printf("Please create a binary tree : \n");
  root=NULL;
    create();
    printf("\n\nIn-Order Traversal : \n");
   in(root);
    getch();

}

//FUNCTION TO CREATE NODES OF A BINARY TREE
create()
{   char item,ch;
    struct tree *queue[20];
    int front=0,rear=0;

    head=(struct tree*)malloc(sizeof(struct tree));
    printf("\n\nEnter information to be stored : " );
    scanf("%c",&item);
    head->info=item;
    root=head;

    rear++;
    queue[rear]=head;

    while(front!=rear)
    {
       front++;
       temp=queue[front];

    //Left Child
    printf("\n\nIs %c has Left child (Y/N)...",temp->info);
    fflush(stdin);
    ch=getche();
                                                                 
    if(ch=='y'||ch=='Y')
    {
     head=(struct tree*)malloc(sizeof(struct tree));
     printf("\n\nEnter information of Left Child : " );
     scanf("%c",&item);
     head->info=item;
     temp->left=head;
     rear++;
     queue[rear]=head;
    }
    else
      temp->left=NULL;

    //Right Child
    printf("\n\nIs %c has Right child (Y/N)...",temp->info);
    fflush(stdin);
    ch=getche();

    if(ch=='y'||ch=='Y')
    {
     head=(struct tree*)malloc(sizeof(struct tree));
     printf("\n\nEnter information of Right Child : " );
     scanf("%c",&item);
     head->info=item;
     temp->right=head;
     rear++;
     queue[rear]=head;
    }
    else
      temp->right=NULL;
  }

  return;
}

in(struct tree *ptr)
{
  if(ptr!=NULL)
  {
   in(ptr->left);
   printf("%c  ",ptr->info);
   in(ptr->right);
  }
  return;
}



