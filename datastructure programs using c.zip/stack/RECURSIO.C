/*Program to calculate factorial of a number using function*/

#include<stdio.h>
#include<conio.h>
main()
{
 int n1,factor;
 clrscr();
 printf("Enter any number : ");
 scanf("%d",&n1);
   factor=fact(n1);
 printf("\nFactorial of %d is = %d",n1,factor);
 getch();
 return;
}

int fact(int n)
{
  int f=1;
  if(n<=1)
     return(1);
  else
   f=n*fact(n-1);
     return(f);
}
