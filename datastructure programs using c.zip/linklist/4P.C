/*Program to inserting a node at the beginning of a list*/

#include<stdio.h>
#include<conio.h>
#include<alloc.h>
struct node
 {
   int info;
   struct node *link;
 };
 struct node *start,*head,*ptr;

void main()
{
  char choice;
  clrscr();
  printf("Please create a link list : \n");
  start=NULL;
  do
  {
    create();
    printf("\nDo you want to create more nodes (Y/N)...");
    fflush(stdin);
    scanf("%c",&choice);
  }while(choice=='y'||choice=='Y');
   ptr->link=NULL;

    traverse();

  do
  {
    insert();
    printf("\n\nDo you want to insert again(Y/N)...");
    fflush(stdin);
    scanf("%c",&choice);
  }while(choice=='y'||choice=='Y');
}

//FUNCTION TO CREATE ELEMENTS
create()
{
   head=(struct node*)malloc(sizeof(struct node));
    printf("\nEnter information in node : " );
    scanf("%d",&head->info);

    if(start!=NULL)
    {
       ptr->link=head;
       ptr=head;
    }
    else
       start=ptr=head;
  return;
}

//FUNCTION TO TRAVERSE ELEMENTS
traverse()
{
   printf("\n\nElements in link list are : ");
    ptr=start;

   while(ptr!=NULL)
   {
     printf("\n%d",ptr->info);
     ptr=ptr->link;
   }
   return;
}

//FUNCTION TO INSERT ELEMENT AT BEGINNING
insert()
{
  int item;
  struct node *nnew;
   printf("\n\nEnter information in new node : ");
   scanf("%d",&item);
   nnew=(struct node*)malloc(sizeof(struct node));
   nnew->info=item;
   nnew->link=start;
   start=nnew;
   traverse();
 return;
}
