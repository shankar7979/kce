/*Program to search an item and print its location in Circular Header List*/

#include<stdio.h>
#include<conio.h>
#include<alloc.h>
struct node
 {
   int info;
   struct node *link;
 };
 struct node *start,*head,*ptr;

void main()
{
  char choice;
  clrscr();
  printf("Please create a Circular Header Link List : \n");
  start=NULL;
  do
  {
    create();
    printf("\nDo you want to create more nodes (Y/N)...");
    fflush(stdin);
    scanf("%c",&choice);
  }while(choice=='y'||choice=='Y');
   ptr->link=start;

    traverse();

  do
  {
     search();
    printf("\n\nDo you want to continue searching (Y/N)...");
    fflush(stdin);
    scanf("%c",&choice);
  }while(choice=='y'||choice=='Y');
}

//FUNCTION TO CREATE ELEMENTS
create()
{
   static int count=0;
    if(count==0)
    {
     head=(struct node*)malloc(sizeof(struct node));
     printf("\nEnter information in Header Node : " );
     scanf("%s",&head->info);
     start=ptr=head;
     count++;
    }

    head=(struct node*)malloc(sizeof(struct node));
    printf("\nEnter information to be stored : " );
    scanf("%d",&head->info);

      ptr->link=head;
      ptr=head;
  return;
}

//FUNCTION TO TRAVERSE ELEMENTS
traverse()
{
   printf("\n\nTraversed elements in link list are : ");
    ptr=start->link;

   while(ptr!=start)
   {
     printf("\n%d",ptr->info);
     ptr=ptr->link;
   }
   return;
}

//FUNCTION TO SEARCH ELEMENT
search()
{
  int item;
  struct node *loc;
  printf("\n\nEnter ITEM to be searched : ");
  scanf("%d",&item);
 ptr=start->link;
 while(ptr!=start)
 {
   if(item==ptr->info)
    {
     loc=ptr;
     printf("\nItem found at %d location",loc);
     return;
    }
   else
    ptr=ptr->link;
 }
  printf("\nItem is not in the link list");
  return;
}