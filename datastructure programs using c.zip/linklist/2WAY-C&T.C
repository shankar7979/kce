/*Program to create and traverse a 2-way link list*/

#include<stdio.h>
#include<conio.h>
#include<alloc.h>
struct node
 {
   int info;
   struct node *back;
   struct node *forw;
 };
 struct node *start,*last,*head,*ptr;

void main()
{
  char choice;
  clrscr();
  printf("Please create a link list : \n");
  start=NULL;
  do
  {
    create();
    printf("\nDo you want to create more nodes (Y/N)...");
    fflush(stdin);
    scanf("%c",&choice);
  }while(choice=='y'||choice=='Y');

    last=head;
    last->forw=NULL;

    traverse_forw();
    traverse_back();

    getch();

}

//FUNCTION TO CREATE NODES
create()
{
   head=(struct node*)malloc(sizeof(struct node));
    printf("\nEnter information to be stored : " );
    scanf("%d",&head->info);

    if(start!=NULL)
    {
       ptr->forw=head;
       head->back=ptr;
       ptr=head;
    }
    else
    {
       start=ptr=head;
       start->back=NULL;
    }
  return;
}

//FUNCTION TO TRAVERSE ELEMENTS USING FORWARD POINTER
traverse_forw()
{
   printf("\n\nTraversed elements from front of link list are : ");
    ptr=start;

   while(ptr!=NULL)
   {
     printf("\n%d",ptr->info);
     ptr=ptr->forw;
   }
   return;
}

//FUNCTION TO TRAVERSE ELEMENTS USING BACKWARD POINTER
traverse_back()
{
   printf("\n\nTraversed elements from back of link list are : ");
    ptr=last;

   while(ptr!=NULL)
   {
     printf("\n%d",ptr->info);
     ptr=ptr->back;
   }
   return;
}
