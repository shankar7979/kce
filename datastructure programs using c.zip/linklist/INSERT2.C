/*Program to insert node at end of link list*/

#include<stdio.h>
#include<conio.h>
#include<alloc.h>
struct node
 {
   int info;
   struct node *ptr;
 }*first,*head,*temp;

void main()
{ int item;
  char choice;
  clrscr();
  first=NULL;
  do
  {
    head=(struct node*)malloc(sizeof(struct node));
    printf("\nEnter information to be stored : " );
    scanf("%d",&head->info);

    if(first!=NULL)
    {
       temp->ptr=head;
       temp=head;
    }
    else
       first=temp=head;

    printf("\nDo you want to continue (Y/N)...");
    fflush(stdin);
    scanf("%c",&choice);
  }while(choice=='y'||choice=='Y');

   temp->ptr=NULL;
   traverse();

   printf("\nEnter info : ");
   scanf("%d",&item);
   head=(struct node*)malloc(sizeof(struct node));

   head->info=item;
   head->ptr=NULL;
   temp->ptr=head;
   traverse();
 getch();
}


traverse()
{  struct node *p;
   printf("\n\nTraversed elements : ");
    temp=first;

   while(temp!=NULL)
   {
     printf("\n%d",temp->info);
  // p=temp;
     temp=temp->ptr;
   }
  // temp=p;
}