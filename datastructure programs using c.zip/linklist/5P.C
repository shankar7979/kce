/*Program to find location & inserting node at location in sorted link list
   (ascending order)*/

#include<stdio.h>
#include<conio.h>
#include<alloc.h>
struct node
 {
   int info;
   struct node *link;
 };
 struct node *start,*ptr,*loc;
 int item;
void main()
{
  char choice;
  clrscr();
  printf("Please create a link list : \n");
  start=NULL;

  do
  {
    insert();
    printf("\n\nDo you want to insert again (Y/N)...");
    fflush(stdin);
    scanf("%c",&choice);
  }while(choice=='y'||choice=='Y');
}

//FUNCTION TO INSERT ITEM IN SORTED LIST
insert()
{
  struct node *nnew;
  printf("\n\nEnter ITEM to be inserted : ");
  scanf("%d",&item);
   find();

  nnew=(struct node*)malloc(sizeof(struct node));
  nnew->info=item;

    if(loc==NULL)
     {
       nnew->link=start;
       start=nnew;
     }
    else
     {
       nnew->link=loc->link;
       loc->link=nnew;
     }
  traverse();
  return;
}

//FUNCTION TO FIND LOCATION
find()
{
  struct node *save;
  if(start==NULL)
   {
    loc=NULL;
    return;
   }

  if(item<start->info)
   {
    loc=NULL;
    return;
   }

   save=start;
   ptr=start->link;
 while(ptr!=NULL)
 {
   if(item<ptr->info)
    {
     loc=save;
     return;
    }

    save=ptr;
    ptr=ptr->link;
 }
 loc=save;
 return;
}

//FUNCTION TO TRAVERSE ELEMENTS
traverse()
{
   printf("\n\nElements in link list are : ");
    ptr=start;

   while(ptr!=NULL)
   {
     printf("\n%d",ptr->info);
     ptr=ptr->link;
   }
   return;
}
