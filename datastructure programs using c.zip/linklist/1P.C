/*Program to create and traverse a link list*/

#include<stdio.h>
#include<conio.h>
#include<alloc.h>
struct node
 {
   int info;
   struct node *link;
 }*start,*head,*ptr;

void main()
{
  char choice;
  clrscr();
  printf("Please create a link list : \n");
  start=NULL;
  do
  {
    create();
    printf("\nDo you want to create more nodes (Y/N)...");
    fflush(stdin);
    scanf("%c",&choice);
  }while(choice=='y'||choice=='Y');
   ptr->link=NULL;

    traverse();
    getch();
}

//FUNCTION TO CREATE NODES
create()
{
   head=(struct node*)malloc(sizeof(struct node));
    printf("\nEnter information to be stored : " );
    scanf("%d",&head->info);

    if(start!=NULL)
    {
       ptr->link=head;
       ptr=head;
    }
    else
       start=ptr=head;
  return;
}

//FUNCTION TO TRAVERSE ELEMENTS
traverse()
{
   printf("\n\nTraversed elements in link list are : ");
    ptr=start;

   while(ptr!=NULL)
   {
     printf("\n%d",ptr->info);
     ptr=ptr->link;
   }
   return;
}

