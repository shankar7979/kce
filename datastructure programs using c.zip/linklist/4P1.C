/*Program to insert a node at beginning or at end of a link list*/

#include<stdio.h>
#include<conio.h>
#include<alloc.h>
struct node
 {
   int info;
   struct node *link;
 };
 struct node *start,*head,*ptr,*temp;

void main()
{
  char choice;
  int ch;
  clrscr();
  printf("Please create a link list : \n");
  start=NULL;
  do
  {
    create();
    printf("\nDo you want to create more nodes (Y/N)...");
    fflush(stdin);
    scanf("%c",&choice);
  }while(choice=='y'||choice=='Y');
   ptr->link=NULL;

  //  traverse();
    clrscr();
   printf("Available choices are : ");
   printf("\n\nPress 1: For Inserting Node at Beginning");
   printf("\n\nPress 2: For Inserting Node at End");
   printf("\n\nPress 3: For Exit");
   choice='y';
   while(choice=='y'||choice=='Y')
   {
    printf("\n\nEnter your choice : ");
    scanf("%d",&ch);
    switch(ch)
    {
     case 1:
		insert();
		head->link=start;
		start=head;
		break;

     case 2:
		insert();
		ptr=start;
		while(ptr!=NULL)
		{
		   temp=ptr;
		   ptr=ptr->link;
		}
		temp->link=head;
		head->link=NULL;
		break;

     default:
		getch();
		exit();
     }

     traverse();
     printf("\n\nDo you want to insert more nodes (Y/N)...");
     fflush(stdin);
     scanf("%c",&choice);
  }
}

//FUNCTION TO CREATE NODES
create()
{
   head=(struct node*)malloc(sizeof(struct node));
    printf("\nEnter information in node : " );
    scanf("%d",&head->info);

    if(start!=NULL)
    {
       ptr->link=head;
       ptr=head;
    }
    else
       start=ptr=head;
  return;
}

//FUNCTION TO TRAVERSE NODES
traverse()
{
   printf("\n\nElements in link list are : ");
    ptr=start;

   while(ptr!=NULL)
   {
     printf("\n%d",ptr->info);
     ptr=ptr->link;
   }
   return;
}

//FUNCTION TO INSERT NEW NODE
insert()
{
  int item;
   printf("\n\nEnter information in new node : ");
   scanf("%d",&item);
   head=(struct node*)malloc(sizeof(struct node));
   head->info=item;
    return;
}

