/*Pattern Matching Algorithm 1st*/

#include<stdio.h>
#include<conio.h>
#include<string.h>
main()
{
 char s[20],p[20];
 int ls,lp,i,k,max,index,count=0;
 clrscr();
 printf("Enter the string : ");
 scanf("%s",s);
 ls=strlen(s);
 printf("Enter the pattern : ");
 scanf("%s",p);
 lp=strlen(p);

 k=1;
 max=ls-lp+1;
 while(k<=max)
 {
   for(i=0;i<lp;i++)
   {
    if(p[i]!=s[k+i-1])
     {
       count++;
       break;
     }
    }

   if(count==0)
   {
     index=k;
     printf("Pattern matches at index : %d",index);
     getch();
     exit();
   }
   k++;
   count=0;
 }
 printf("Pattern do not match");
 getch();
}
