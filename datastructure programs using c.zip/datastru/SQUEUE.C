/*Program to perform operations in simple queue*/

#include<stdio.h>
#include<conio.h>
int queue[10],max=5;
int front=0,rear=0;
main()
{
 char ch;
 clrscr();
 printf("Available choices are :\n");
 printf("\nPress 1 : For Insertion");
 printf("\nPress 2 : For Deletion");
 printf("\nPress 3 : For Traversal");
 printf("\nPress 4 : For Exit");
  while(1)
  {
   printf("\n\nEnter your choice : ");
   fflush(stdin);
   scanf("%c",&ch);
   switch(ch)
   {
     case '1':
	      insert();
	       break;
     case '2':
	      del();
	       break;
     case '3':
	      traverse();
	       break;
     case '4':
	      exit();

     default:
	      printf("\nSorry! you entered wrong choice");
   }
  /*	printf("\n\nDo you want to continue (Y/N)..");
	fflush(stdin);
	ch=getche();*/
  }
}

insert()
{
  int item;
  if(rear==max)
  {
    printf("\nOverflow Condition");
    return;
  }

  if(front==0)
  {
    front=1;
    rear=1;
  }
  else
    rear=rear+1;
   printf("Enter the element : ");
   scanf("%d",&item);
   queue[rear]=item;
  return;
}

del()
{
  int item;
  if(front==0)
  {
    printf("\nUnderflow Condition");
    return;
  }
    item=queue[front];
    printf("Element deleted is : %d",item);
  if(front==rear)
  {
    front=0;
    rear=0;
  }
  else
    front=front+1;
  return;
}

traverse()
{
  int i;
  if(front==0&&rear==0)
  {
   printf("Queue is empty");
   return;
  }
   printf("\nTraversed elements are : ");
   for(i=front;i<=rear;i++)
     printf("\n%d",queue[i]);
 return;
}