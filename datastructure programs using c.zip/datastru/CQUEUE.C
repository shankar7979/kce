/*Program to perform operations in circular queue*/

#include<stdio.h>
#include<conio.h>
int queue[10],max=4;
int front=0,rear=0;
main()
{
 char ch;   //char ch='y';
 clrscr();
  printf("Available choices are :\n");
  printf("\nPress 1 : For Insertion");
  printf("\nPress 2 : For Deletion");
  printf("\nPress 3 : For Traversal");
  printf("\nPress 4 : For Exit");
 //while(ch=='y'||ch=='Y')
 while(1)
 {
  printf("\n\nEnter your choice : ");
  fflush(stdin);
  scanf("%c",&ch);
  switch(ch)
  {
   case '1':
	    insert();
	     break;
   case '2':
	    del();
	     break;
   case '3':
	    traverse();
	     break;
   case '4':
	    exit();

   default:
	    printf("\nSorry! you entered wrong choice");
  }
	/*printf("\n\nDo you want to continue (Y/N)..");
	fflush(stdin);
	ch=getche();*/
 }
//  return;
}

insert()
{
  int item;
   if((front==1&&rear==max)||(front==rear+1))
   {
    printf("\nOverflow Condition");
    return;
   }

   if(front==0)
   {
    front=1;
    rear=1;
   }
   else
    if(rear==max)
      rear=1;
    else
      rear=rear+1;
   printf("Enter the element : ");
   scanf("%d",&item);
   queue[rear]=item;
  return;
}

del()
{
  int item;
   if(front==0)
   {
    printf("\nUnderflow Condition");
    return;
   }
    item=queue[front];
    printf("Element deleted is : %d",item);
    if(front==rear)
    {
      front=0;
      rear=0;
    }
    else
     if(front==max)
	front=1;
     else
	front=front+1;
   return;
}

traverse()
{
  int i;
   if(front==0&&rear==0)
   {
    printf("Queue is empty");
    return;
   }
   printf("\nTraversed elements are : ");

   if(rear<front)
   {
     for(i=front;i<=max;i++)
	printf("\n%d",queue[i]);
     for(i=1;i<=rear;i++)
	printf("\n%d",queue[i]);
   }

   if(front<rear)
   {
     for(i=front;i<=rear;i++)
	printf("\n%d",queue[i]);
   }

   if(front==rear)
      printf("\n%d",queue[front]);

 return;
}