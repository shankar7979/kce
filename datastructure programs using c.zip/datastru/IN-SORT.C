//PROGRAM FOR INSERTION SORT

#include<stdio.h>
#include<conio.h>
void main()
{
 int a[20],i,n,ptr,temp;
 clrscr();
 printf("Enter no. of elements in array : ");
 scanf("%d",&n);
 printf("\nElements of array are: \n");
 for(i=0;i<n;i++)
   scanf("%d",&a[i]);

  for(i=1;i<n;i++)
  {
     temp=a[i];
     ptr=i-1;

    while(temp<a[ptr]&&ptr>=0)
    {
      a[ptr+1]=a[ptr];
      ptr=ptr-1;
    }
    a[ptr+1]=temp;
  }

 printf("\nSorted array : ");
 for(i=0;i<n;i++)
   printf("\n%d",a[i]);
 getch();
}
