/*Program to perform operations in stack*/

#include<stdio.h>
#include<conio.h>
int stack[10],max=10;
int top=-1;
main()
{
 char ch='y';
 clrscr();
 printf("Available choices are :\n\n");
 printf("Press 1 : For Push\n");
 printf("Press 2 : For Pop \n");
 printf("Press 3 : For Traverse \n");
 printf("Press 4 : For exit \n");
  while(ch=='y'||ch=='Y')
  {
   printf("\n\nEnter your choice : ");
   fflush(stdin);
   scanf("%c",&ch);
   switch(ch)
   {
     case '1':
	      push();
	       break;
     case '2':
	      pop();
	       break;
     case '3':
	      traverse();
	       break;
     case '4':
	      exit();

     default:
	      printf("\nSorry! you entered wrong choice");
   }
	printf("\n\nDo you want to continue (Y/N)..");
	fflush(stdin);
	ch=getche();
  }
 return;
}

push()
{
  int item;
  if(top==max-1)
  {
    printf("\nOverflow Condition");
    return;
  }

   printf("Enter the element : ");
   scanf("%d",&item);
   top=top+1;
   stack[top]=item;
  return;
}

pop()
{
  int item;
  if(top==-1)
  {
    printf("\nUnderflow Condition");
    return;
  }
    item=stack[top];
    top=top-1;
    printf("Poped item is : %d",item);
  return;
}

traverse()
{
  int i;
  if(top==-1)
  {
   printf("Stack is empty");
   return;
  }
   printf("\nTraversed elements are : ");
   for(i=top;i>=0;i--)
     printf("\n%d",stack[i]);
 return;
}