/*Program for Quick Sort*/

#include<stdio.h>
#include<conio.h>
int loc,a[25];

main()
{
 int top=0,n,i,lower[20],upper[20];
 int beg,end;
  clrscr();
 printf("Enter no. of elements : ");
 scanf("%d",&n);
 printf("Enter elements : \n");
 for(i=1;i<=n;i++)
 {
  scanf("%d",&a[i]);
 }

  if(n>1)
  {
    top=top+1;
    lower[1]=1;
    upper[1]=n;
  }

  while(top!=0)
  {
     beg=lower[top];
     end=upper[top];
     top=top-1;

    quick(beg,end);

   if(beg<loc-1)
   {
     top=top+1;
     lower[top]=beg;
     upper[top]=loc-1;
   }

   if(loc+1<end)
   {
     top=top+1;
     lower[top]=loc+1;
     upper[top]=end;
   }
  }

  printf("\n\nSorted list : ");
  for(i=1;i<=n;i++)
  {
    printf("\n%d",a[i]);
  }
 getch();
 return;
}

quick(int left,int right)
{
 int temp;

  loc=left;
  while(1)
  {
   while((a[loc]<=a[right])&&loc!=right)
   {
     right=right-1;
   }

   if(loc==right)
      return;

   if(a[loc]>a[right])
   {
      temp=a[loc];
      a[loc]=a[right];
      a[right]=temp;

      loc=right;
   }

   while((a[left]<=a[loc])&&left!=loc)
   {
      left=left+1;
   }

   if(loc==left)
      return;

   if(a[left]>a[loc])
   {
      temp=a[loc];
      a[loc]=a[left];
      a[left]=temp;

      loc=left;
   }
  }
}
