/*Program to convert IN-FIX to POST-FIX expression*/

#include<stdio.h>
#include<conio.h>
#include<string.h>
char q[20],p[20],stack[20],ch,ch1;
int j=-1,top=0,y=6;
int i=-1,k=0;

void main()
{
 clrscr();
 printf("Enter Infix expression : \n\n Q: ");
 scanf("%s",q);
 k=strlen(q);
 q[k]=')';

   top++;
  stack[top]='(';
  printf("\nSymbol Scanned       STACK              Expression P\n");
l1:
  while(stack[top]!=0)
  {
    i++;
    ch=q[i];
    if((ch>='A'&&ch<='Z')||(ch>='a'&&ch<='z'))
    {
       j++;
       p[j]=ch;
       display();
       goto l1;
    }

    if(ch=='(')
    {
       top++;
       stack[top]=ch;
       display();
       goto l1;
    }

    if(ch==')')
    {
      while(stack[top]!='(')
      {
	 j++;
	 p[j]=stack[top];
	 top--;
      }
      top--;
      display();
    }

    else
     {

	ch1=stack[top];
	while(ch=='^'&&ch1=='^')
	  pop();
	while((ch=='*'||ch=='/')&&(ch1=='^'||ch1=='*'||ch1=='/'))
	  pop();
	while((ch=='+'||ch=='-')&&(ch1!='('))
	  pop();

	top++;
	stack[top]=ch;
	display();
     }

   }

  printf("\n\nPost fix expression : \n\n P: ");
  for(k=0;k<=j;k++)
    printf("%c ",p[k]);

getch();
}

pop()
{
   j++;
   p[j]=ch1;
   top--;
   ch1=stack[top];
   return;
}

display()
{  gotoxy(2,y);
   printf("%2d    %c            ",i+1,ch);
   for(k=1;k<=top;k++)
   {
     printf("%c ",stack[k]);
   }
   gotoxy(40,y);
   for(k=0;k<=j;k++)
   {
     printf("%c ",p[k]);
   }
   y=y+2;
   return;
}
