/*Program  to convert IN-FIX to POST-FIX expression
  (only Post-fix expression get not complete solution*/

#include<stdio.h>
#include<conio.h>
#include<string.h>
char p[20],stack[20],ch1;
int j=-1,top=0;
void main()
{
 char q[25],ch;
 int i=-1,k=0;
 clrscr();
 printf("Enter Infix expression : \n");
 scanf("%s",q);
 k=strlen(q);
 q[k]=')';

   top++;
  stack[top]='(';
l1:
  while(stack[top]!=0)
  {
    i++;
    ch=q[i];
    if((ch>='A'&&ch<='Z')||(ch>='a'&&ch<='z'))
    {
       j++;
       p[j]=ch;
       goto l1;
    }

    if(ch=='(')
    {
       top++;
       stack[top]=ch;
       goto l1;
    }

    if(ch==')')
    {
      while(stack[top]!='(')
      {
	 j++;
	 p[j]=stack[top];
	 top--;
      }
      top--;
    }

    else
     {

	ch1=stack[top];
	while(ch=='^'&&ch1=='^')
	  pop();
	while((ch=='*'||ch=='/')&&(ch1=='^'||ch1=='*'||ch1=='/'))
	  pop();
	while((ch=='+'||ch=='-')&&(ch1!='('))
	  pop();

	top++;
	stack[top]=ch;
     }
   }

  printf("\n\nPost fix expression : \n");
  for(k=0;k<=j;k++)
    printf("%c ",p[k]);

getch();
}

pop()
{
   j++;
   p[j]=ch1;
   top--;
   ch1=stack[top];
   return;
}


