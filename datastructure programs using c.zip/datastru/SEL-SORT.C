/*Program for Selection Sort*/

#include<stdio.h>
#include<conio.h>
void main()
{
int a[40],i,j,n,min,loc,temp;
clrscr();
 printf("Enter no. of elements in array : ");
 scanf("%d",&n);
 printf("\nElements of array are : \n");
 for(i=0;i<n;i++)
  scanf("%d",&a[i]);

  for(i=0;i<n;i++)
  {
     min=a[i];
     loc=i;

    for(j=i+1;j<n;j++)
    {
      if(min>a[j])
      {
	min=a[j];
	loc=j;
      }
    }

    temp=a[i];
    a[i]=a[loc];
    a[loc]=temp;
  }

 printf("\nSorted array : ");
  for(i=0;i<n;++i)
    printf("\n%d",a[i]);
 getch();
}
