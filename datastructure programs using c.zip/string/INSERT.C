/*Program for insertion a character in any string*/

#include<stdio.h>
#include<conio.h>
#include<string.h>
main()
{
  int i,loc,length;
  char a[20],ch;
  clrscr();
  printf("\nEnter any string : \n");
  scanf("%s",a);
  length=strlen(a);
  printf("\nEnter the location where you want to insert : ");
  scanf("%d",&loc);
  fflush(stdin);
  printf("\nEnter character to be inserted : ");
  scanf("%c",&ch);

   for(i=length-1;i>=loc-1;i--)
   {
     a[i+1]=a[i];
   }
     a[loc-1]=ch;
     a[length+1]='\0';
     printf("\nNew string is : %s",a);
   getch();
}
