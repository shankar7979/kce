/*Program to copy a string*/

#include<stdio.h>
#include<conio.h>
main()
{
 int i=0;
 char source[20],target[20];
 clrscr();
 printf("Enter a string : ");
 scanf("%s",source);
  while(source[i]!='\0')
  {
    target[i]=source[i];
    i++;
  }
   target[i]='\0';
  printf("\nSource string is = %s",source);
  printf("\nTarget string is = %s",target);
 getch();
}