/*Program to concatenation two strings*/

#include<stdio.h>
#include<conio.h>
main()
{
 int i=0,length=0;
 char a[20],b[10];
 clrscr();
 printf("Enter first string : ");
 scanf("%s",a);
 printf("Enter second string : ");
 scanf("%s",b);

 while(a[i]!='\0')
 {
   length++;
   i++;
 }
 i=0;
 while(b[i]!='\0')
 {
   a[length+i]=b[i];
   i++;
 }
 printf("\nCombined strings are %s",a);
 getch();
}