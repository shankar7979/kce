/*Program to compare two strings*/

#include<stdio.h>
#include<conio.h>
main()
{
 int i=0,l1=0,l2=0;
 char a[20],b[10];
 clrscr();
 printf("Enter first string : ");
 scanf("%s",a);
  while(a[i]!='\0')
  {
    l1++;
    i++;
  }
 printf("Enter second string : ");
 scanf("%s",b);
 i=0;
 while(b[i]!='\0')
  {
    l2++;
    i++;
  }

  if(l1!=l2)
  {
    printf("Strings are not equal");
    getch();
    exit();
  }

 for(i=0;i<l1;i++)
 {
   if(a[i]!=b[i])
     {
       printf("\nTwo string are not equal");
       getch();
       exit();
     }
 }
    printf("\nTwo string are equal");
  getch();
}