/*Program to calculate length of string & perform copy,concatenation
   & comparison of string using switch statement*/

#include<stdio.h>
#include<conio.h>
#include<string.h>
main()
{
 int l,n;
 char a[20],b[20],ch;
 clrscr();
 printf("Available choices are :\n\n");
 printf("Press 1 : For calculating Length of a string \n");
 printf("Press 2 : For Copy any string \n");
 printf("Press 3 : For Comparison of two strings \n");
 printf("Press 4 : For Concatenation of two strings \n");
 printf("Press 5 : For exit \n");
 l1:
 printf("\n\nEnter your choice : ");
 scanf("%d",&n);
 switch(n)
 {
  case 1:
	 printf("Enter any string : ");
	 scanf("%s",a);
	 l=strlen(a);
	 printf("\nLength of string %s = %d",a,l);
	 goto l2;

  case 2:
	 printf("Enter a string : ");
	 scanf("%s",a);
	 strcpy(b,a);
	 printf("\nCopied string is = %s",b);
	  goto l2;

  case 3:
	printf("Enter first string : ");
	scanf("%s",a);
	printf("Enter second string : ");
	scanf("%s",b);
	if(strcmp(a,b)==0)
	  printf("\nTwo string are equal");
	else
	  printf("\nTwo string are not equal");
	  goto l2;

  case 4:
	printf("Enter first string : ");
	scanf("%s",a);
	printf("Enter second string : ");
	scanf("%s",b);
	strcat(a,b);
	printf("\nCombined strings are %s",a);
	 goto l2;

  case 5:
	exit();

  default:
	printf("\nSorry! you entered wrong choice");
      l2:
	printf("\n\nDo you want to continue (Y/N)..");
	ch=getche();
	 if(ch=='y'|| ch=='Y')
	  goto l1;
	 else
	  { getch();
	    exit();
	  }
 }
}