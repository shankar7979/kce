/*Program to delete a character from any string*/

#include<stdio.h>
#include<conio.h>
#include<string.h>
main()
{
  char a[20],ch;
  int i,loc,length;
  clrscr();
  printf("\nEnter any string : ");
  scanf("%s",a);
  length=strlen(a);
  printf("\nEnter the location for delete character : ");
  scanf("%d",&loc);
     ch=a[loc-1];
   for(i=loc-1;i<length;i++)
   {
     a[i]=a[i+1];
   }
     a[length-1]='\0';
     printf("\nDeleted character is : %c from location %d",ch,loc);
     printf("\n\nNew string is : %s",a);
    getch();
}
