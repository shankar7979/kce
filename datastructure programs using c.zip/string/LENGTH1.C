/*Program to calculate length of a string without using function*/

#include<stdio.h>
#include<conio.h>
main()
{ int i=0,length=0;
  char s[15];
  clrscr();
  printf("Enter any string : \n");
  scanf("%s",s);
   while(s[i]!='\0')
   {
      length++;
      i++;
   }
    printf("\nLength of string = %d",length);
     getch();
}

